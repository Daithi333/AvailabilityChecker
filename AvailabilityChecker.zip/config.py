
config = {
    'TopicArn': 'arn:aws:sns:eu-west-1:757607970807:ProductAlert'
}
